//
//  ViewController.swift
//  CarthageDemo
//
//  Created by KADTHALA SNEHA on 27/02/19.
//  Copyright © 2019 KADTHALA SNEHA. All rights reserved.
//

import UIKit
import SwiftyJSON

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       jsonParsing()
    }
    func jsonParsing(){
        guard let url = URL(string: "https://api.myjson.com/bins/odim1")
            else{
                return
        }
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            guard let dataResponse = data,
                error == nil else {
                    print(error?.localizedDescription ?? "Response Error")
                    return }
            do{
                let userJson = try JSON(data: dataResponse)
                if let name = userJson["name"].string {
                    print("name is :\(name)")
                }
                if let year  = userJson["birthday"]["year"].number,
                    let month = userJson["birthday"]["month"].number,
                    let day   = userJson["birthday"]["day"].number {
                    print("data od birth is: \(day)/\(month)/\(year)")
                    
                }
                if let isActive = userJson["isActive"].bool {
                    print("is active: \(isActive)")
                    
                }
                if let contactArr = userJson["contacts"].array {
                    for contactDict in contactArr {
                        if let type = contactDict["type"].string {
                            print(type)
                            // get type
                        }
                        if let value = contactDict["value"].string {
                            print(value)
                            
                        }
                    }
                }
            }
            catch{
                print(error)
            }
            
            
            
            
        }
        task.resume()
    }


}

